"use strict";
(() => {
var exports = {};
exports.id = 369;
exports.ids = [369,771];
exports.modules = {

/***/ 1771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TheContent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function TheContent({ content  }) {
    function htmlspcecial_decode(text) {
        var map = {
            "&amp;": "&",
            "&#038;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"',
            "&#039;": "'",
            "&#8217;": "’",
            "&#8216;": "‘",
            "&#8211;": "–",
            "&#8212;": "—",
            "&#8230;": "…",
            "&#8221;": "”"
        };
        return text.replace(/\&[\w\d\#]{2,5}\;/g, function(m) {
            return map[m];
        });
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("article", {
            className: "the_content",
            dangerouslySetInnerHTML: {
                __html: htmlspcecial_decode(content)
            }
        })
    }));
};


/***/ }),

/***/ 7915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WrapContent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



function WrapContent({ children  }) {
    const { 0: expand , 1: setExpand  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        next_router__WEBPACK_IMPORTED_MODULE_2___default().events.on("routeChangeComplete", ()=>{
            setExpand(false);
        });
    }, []);
    //   const toggleContent = useCallback((e) => {
    //     e.preventDefault();
    //     let _this = e.target;
    //     let target = _this.getAttribute("data-target");
    //     let main_content = document.querySelector(`${target}`);
    //     let hide_content = document.querySelector(`${target} > .hide-content`);
    //     if (!_this.classList.contains(`is-show`)) {
    //       main_content.classList.add(`show-full-content`);
    //       hide_content.classList.add(`removeBlur`);
    //       _this.classList.add(`is-show`);
    //       _this.innerText = "Thu gọn";
    //     } else {
    //       main_content.classList.remove(`show-full-content`);
    //       hide_content.classList.remove(`removeBlur`);
    //       _this.classList.remove(`is-show`);
    //       _this.innerText = "Đọc thêm";
    //     }
    //   }, []);
    //   useEffect(() => {
    //     const toggleContent = (e) => {
    //       e.preventDefault();
    //       setExpand(!expand);
    //     };
    //     const button = document.querySelector(`.btn-view-full-content`);
    //     button.addEventListener(`click`, toggleContent);
    //     return () => {
    //       button.removeEventListener(`click`, toggleContent);
    //     };
    //   }, [expand]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `the-service-content` + (expand ? " show-full-content" : ""),
        id: "noidung",
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `hide-content` + (expand ? "removeBlue" : ""),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: "#!",
                    className: "btn-view-full-content",
                    "data-target": "#noidung",
                    onClick: ()=>{
                        setExpand(!expand);
                    },
                    children: expand ? "Thu gọn" : "Đọc th\xeam"
                })
            })
        ]
    }));
};


/***/ }),

/***/ 4516:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_posts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1237);
/* harmony import */ var _components_Detail_TheContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1771);
/* harmony import */ var _components_Detail_WrapContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7915);
/* harmony import */ var _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(561);
/* harmony import */ var _components_Post_PostItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9115);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9103);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_7__, _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_6__]);
([_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_7__, _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










function Tag({ term , apiUrl  }) {
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const slug = route.query.slug;
    const { 0: items , 1: setItems  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const fetchData = async ()=>{
            const post = await _api_posts__WEBPACK_IMPORTED_MODULE_3__/* ["default"].all */ .Z.all({
                term: slug
            });
            setItems(post);
        };
        fetchData();
    }, [
        apiUrl
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: term.seo_title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: term.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: term.seo_title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "article"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:type",
                        content: term.mimeType
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:width",
                        content: term.imageWidth
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:height",
                        content: term.imageHeight
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:alt",
                        content: term.seo_title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: term.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: term.share_image
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "amphtml",
                        href: term.amp_link
                    })
                ]
            }),
            term.content && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Detail_WrapContent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                children: [
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Detail_TheContent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        content: term.content
                    })
                ]
            }),
            _api_posts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                items: items,
                setItems: setItems,
                apiUrl: apiUrl,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
            })
        ]
    }));
}
async function getStaticPaths() {
    const API_URL = process.env.API_URL;
    const res = await fetch(`${API_URL}/api/term/all`);
    const data = await res.json();
    return {
        paths: data.map((x)=>({
                params: {
                    slug: x.slug.toString()
                }
            })
        ),
        fallback: `blocking`
    };
}
async function getStaticProps(context) {
    const APP_URL = process.env.API_URL;
    const slug = context.params?.slug;
    const res_term = await fetch(`${APP_URL}/api/term/${slug}`);
    const data_term = await res_term.json();
    const url = query_string__WEBPACK_IMPORTED_MODULE_9___default().stringifyUrl({
        url: `${APP_URL}/api/post`,
        query: {
            term: slug
        }
    });
    return {
        props: {
            apiUrl: url,
            term: data_term
        },
        revalidate: 60
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tag);

});

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9103:
/***/ ((module) => {

module.exports = require("query-string");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ 4316:
/***/ ((module) => {

module.exports = require("vanilla-lazyload");

/***/ }),

/***/ 7269:
/***/ ((module) => {

module.exports = import("reactstrap");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,642,793,237], () => (__webpack_exec__(4516)));
module.exports = __webpack_exports__;

})();