(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3788:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__BH5s_",
	"block-footer2": "Footer_block-footer2__NlYdA",
	"copyright": "Footer_copyright__1_0lf",
	"powered": "Footer_powered__Gu_RI",
	"block-footer1": "Footer_block-footer1__kJCn6",
	"footer-content": "Footer_footer-content__IyuhM",
	"footer-tag": "Footer_footer-tag__YCLoT",
	"cloud-tag": "Footer_cloud-tag__IiTLe"
};


/***/ }),

/***/ 7151:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Header_header__ubBbX",
	"main-logo": "Header_main-logo__t2722",
	"logo-svg": "Header_logo-svg__48pp9",
	"logo-text": "Header_logo-text__JFE4B",
	"block-form-search": "Header_block-form-search__mcrH1",
	"form-search": "Header_form-search__q4uDA",
	"txt-search": "Header_txt-search__KVDCV",
	"btn-search": "Header_btn-search__ssUnV",
	"btn-close-menu": "Header_btn-close-menu__g_FzR",
	"nav-right": "Header_nav-right__XD0Uv",
	"nav-right-item": "Header_nav-right-item__m_nZF",
	"nav-right-item-permalink": "Header_nav-right-item-permalink__dqoFp",
	"sub-menu-right": "Header_sub-menu-right__tkT_Y",
	"btn-open-modal": "Header_btn-open-modal__ZnCeA",
	"btn-open-search-m": "Header_btn-open-search-m__EJk9V",
	"btn-menu": "Header_btn-menu__MbYM3",
	"header-left": "Header_header-left__SJsdO",
	"open-form-search": "Header_open-form-search__K_Zt7"
};


/***/ }),

/***/ 7257:
/***/ ((module) => {

// Exports
module.exports = {
	"term-title": "Term_term-title__RuvkU",
	"term-image": "Term_term-image__qEM_I",
	"term-content": "Term_term-content__CF4dd",
	"term-item": "Term_term-item__RamKl",
	"active": "Term_active__h4qO7"
};


/***/ }),

/***/ 1629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DropZone)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);

/* eslint-disable @next/next/no-img-element */ 

function DropZone({ innerRef , onChange , sendSuccess , setSendSuccess ,  }) {
    const { 0: preview , 1: setPreview  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const handlePreviewImg = (e)=>{
        const file = e.target.files[0];
        if (e.target.files.length) {
            setPreview(URL.createObjectURL(file));
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (sendSuccess && preview) {
            URL.revokeObjectURL(preview);
            setPreview(undefined);
            setSendSuccess(false);
        }
        return ()=>{
            if (preview) {
                URL.revokeObjectURL(preview);
            }
        };
    }, [
        preview,
        sendSuccess
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const dropZone = document.getElementById(`file_upload`);
        const dropZoneElement = dropZone.closest(".drop-zone");
        dropZoneElement.addEventListener("click", (e)=>{
            dropZone.click();
        });
        dropZone.addEventListener("change", (e)=>{});
        dropZoneElement.addEventListener("dragover", (e)=>{
            e.preventDefault();
            dropZoneElement.classList.add("drop-zone--over");
        });
        [
            "dragleave",
            "dragend"
        ].forEach((type)=>{
            dropZoneElement.addEventListener(type, (e)=>{
                dropZoneElement.classList.remove("drop-zone--over");
            });
        });
        dropZoneElement.addEventListener("drop", (e)=>{
            e.preventDefault();
            if (e.dataTransfer.files.length) {
                dropZone.files = e.dataTransfer.files;
            }
            dropZoneElement.classList.remove("drop-zone--over");
        });
    }, []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "drop-zone",
        children: [
            typeof preview === "undefined" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "drop-zone__prompt",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        src: "/images/file-upload.svg",
                        alt: "Upload",
                        width: 50,
                        height: 60,
                        className: "image-center d-block"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "d-block mb-3 mt-2",
                        children: "K\xe9o thả h\xecnh ảnh hoặc "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "btn btn-primary btn-sm pb-2 pe-3 ps-3 pt-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                            children: "Chọn tệp tin"
                        })
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: preview,
                alt: "Preview",
                className: "img-responsive"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "file",
                name: "file",
                className: "drop-zone__input",
                onChange: (e)=>{
                    handlePreviewImg(e), onChange(e);
                },
                id: "file_upload",
                ref: innerRef
            })
        ]
    }));
};


/***/ }),

/***/ 388:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7269);
/* harmony import */ var _api_axiosClient__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1646);
/* harmony import */ var _redux_actions_theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9515);
/* harmony import */ var _DropZone_DropZone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1629);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([reactstrap__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
([reactstrap__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









function ModalUpload() {
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const GG_SITE = "6Ld6jo4eAAAAALFg_h3D1z5aQ0Bs9OMFXpcbNhv6";
    const { 0: sendSuccess , 1: setSendSuccess  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const openModal = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.theme.openModal
    );
    const handleModal = ()=>{
        dispatch((0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_8__/* .toggleModal */ .$J)(!openModal));
    };
    const { register , handleSubmit , reset , setError , formState: { errors: errors1 , isSubmitting  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const txt_title = register("txt_title", {
        required: "Vui l\xf2ng nhập ti\xeau đề",
        maxLength: {
            value: 256,
            message: `Tiêu đề tối đa 256 ký tự`
        },
        minLength: {
            value: 10,
            message: `Tiêu đề tối thiểu 10 ký tự`
        }
    });
    const txt_content = register("txt_content", {
        maxLength: {
            value: 5000,
            message: `Nội dung tối đa 5000 ký tự`
        }
    });
    const file = register("file");
    const onHandleSubmit = (data)=>{
        return new Promise((resolve)=>{
            setTimeout(()=>{
                let bodyFormData = new FormData();
                bodyFormData.append("txt_title", data.txt_title);
                bodyFormData.append("txt_content", data.txt_content);
                bodyFormData.append("file", data.file[0]);
                bodyFormData.append("gg_recaptcha".ref);
                _api_axiosClient__WEBPACK_IMPORTED_MODULE_6__/* ["default"].post */ .Z.post("/newsletter/send-meme", bodyFormData, {
                    headers: {
                        "Content-Type": "multipart/form-data"
                    }
                }).then((response)=>{
                    if (response.success === "fail") {
                        const errors = response.errors;
                        for(const key in errors){
                            if (Object.hasOwnProperty.call(errors, key)) {
                                const message = errors[key];
                                setError(key, {
                                    type: "manual",
                                    message: message
                                });
                            }
                        }
                    }
                    if (response.success === "success") {
                        reset();
                        setSendSuccess(true);
                    }
                }).catch((error)=>{
                    console.log(error);
                });
                resolve();
            }, 2000);
        });
    };
    const handleCountTextLength = (e)=>{
        let l = 5000 - e.target.value.length;
        document.querySelector(`.length-textarea`).innerText = l < 0 ? 0 : l;
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Modal, {
            isOpen: true,
            toggle: handleModal,
            centered: true,
            size: "lg",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.ModalBody, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                    className: "section-upload",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "upload-header",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn-close btn-close-custom",
                                    type: "button",
                                    "aria-label": "Close",
                                    onClick: handleModal
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                    className: "d-block h3 font-weight-bold",
                                    children: "Gửi meme"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "H\xf4m nay bạn c\xf3 điều g\xec th\xfa vị muốn chia sẻ với mọi người, h\xe3y nội dung ở b\xean dưới !"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Form, {
                            method: "POST",
                            onSubmit: handleSubmit(onHandleSubmit),
                            encType: "multipart/form-data",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Row, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Col, {
                                        lg: "6",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormGroup, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DropZone_DropZone__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    innerRef: file.ref,
                                                    onChange: file.onChange,
                                                    sendSuccess: sendSuccess,
                                                    setSendSuccess: setSendSuccess
                                                }),
                                                errors1?.file && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormFeedback, {
                                                    className: "d-block",
                                                    children: errors1?.file?.message
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Col, {
                                        lg: "6",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormGroup, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Input, {
                                                        type: "text",
                                                        placeholder: "Ti\xeau đề",
                                                        name: "txt_title",
                                                        innerRef: txt_title.ref,
                                                        onChange: txt_title.onChange,
                                                        onBlur: txt_title.onBlur,
                                                        invalid: errors1?.txt_title ? true : false,
                                                        className: "txt_upload"
                                                    }),
                                                    errors1?.txt_title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormFeedback, {
                                                        children: errors1?.txt_title?.message
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormGroup, {
                                                className: "position-relative",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "custom-textarea",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Input, {
                                                                type: "textarea",
                                                                placeholder: "M\xf4 tả",
                                                                name: "txt_content",
                                                                rows: 7,
                                                                innerRef: txt_content.ref,
                                                                onChange: txt_content.onChange,
                                                                onBlur: txt_content.onBlur,
                                                                invalid: errors1?.txt_content ? true : false,
                                                                className: "txt_upload",
                                                                onKeyUp: handleCountTextLength
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "length-textarea",
                                                                children: !sendSuccess && 5000
                                                            })
                                                        ]
                                                    }),
                                                    errors1?.txt_content && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormFeedback, {
                                                        className: "d-block",
                                                        children: errors1?.txt_content?.message
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.FormGroup, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    sitekey: GG_SITE,
                                                    ref: ref
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Col, {
                                        xs: "12",
                                        className: "text-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                            color: "success",
                                            type: "submit",
                                            disabled: isSubmitting,
                                            children: "Gửi meme"
                                        })
                                    }),
                                    isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-loading"
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpload);

});

/***/ }),

/***/ 924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PostFeatured)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _LazyImage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(642);



function PostFeatured({ item  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "sidebar-post-container position-relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    href: `/${item.url}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: "full"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sidebar-post-thumbnail",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LazyImage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        src: item.thumbnail,
                        alt: item.post_title
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sidebar-post-title",
                    children: item.post_title
                })
            ]
        })
    }));
};


/***/ }),

/***/ 3155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3788);
/* harmony import */ var _styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Detail_TheContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1771);




function Footer({ footer , footer_content  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
            className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default().footer),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["block-footer1"]),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "wrapper",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row justify-content-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["footer-content"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Detail_TheContent__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        content: footer_content
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["footer-tag"]),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            children: "Từ kh\xf3a nổi bật"
                                        }),
                                        footer.map((item)=>{
                                            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: `/tag/${item.category_slug}`,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["cloud-tag"]),
                                                    children: [
                                                        "#",
                                                        item.category_title
                                                    ]
                                                })
                                            }, `permalink_footer_${item.id}`));
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["block-footer2"]) + ` text-center`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "wrapper",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "d-flex flex-wrap align-items-center justify-content-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default().copyright),
                                    children: "\xa9 Copyright 2022, All Rights Reserved"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_Footer_module_scss__WEBPACK_IMPORTED_MODULE_3___default().powered),
                                    children: "Powered by memevui.com"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};


/***/ }),

/***/ 7064:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7151);
/* harmony import */ var _styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Modal_ModalUpload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(388);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _redux_actions_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9515);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9103);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Modal_ModalUpload__WEBPACK_IMPORTED_MODULE_3__]);
_Modal_ModalUpload__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* eslint-disable @next/next/no-img-element */ 






function Header() {
    const formSearch = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const openMenu = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.theme.openMenu
    );
    const openModal = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.theme.openModal
    );
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const handleMenu = ()=>{
        const action = (0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_6__/* .toggleMenu */ .js)(!openMenu);
        dispatch(action);
    };
    const handleModal = ()=>{
        const action = (0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_6__/* .toggleModal */ .$J)(!openModal);
        dispatch(action);
    };
    const handleOpenFormSearch = (e)=>{
        e.preventDefault();
        const f = formSearch.current;
        f.classList.toggle((_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["open-form-search"]));
    };
    const handleSearch = (e)=>{
        e.preventDefault();
        let val = e.target.keyword.value;
        if (val) {
            const APP_URL = "https://memevui.com";
            console.log(APP_URL);
            const url = query_string__WEBPACK_IMPORTED_MODULE_5___default().stringifyUrl({
                url: `${APP_URL}/tim-kiem`,
                query: {
                    keyword: val
                }
            });
            console.log(url);
            window.location.href = url;
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().header),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "wrapper",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-flex align-items-center justify-content-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["header-left"]),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "d-flex align-items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["btn-menu"]),
                                            onClick: handleMenu
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["main-logo"]) + ` position-relative`,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                    href: "/",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "full"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["logo-svg"]),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/images/memevui.svg",
                                                        width: 40,
                                                        height: 40,
                                                        alt: "Logo memevui"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["logo-text"]),
                                                    children: "Meme Vui"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["block-form-search"]),
                                            ref: formSearch,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                action: "",
                                                method: "GET",
                                                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["form-search"]),
                                                onSubmit: handleSearch,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "submit",
                                                        className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["btn-search"]),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: "/images/button-search.svg",
                                                            alt: "Button search"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        name: "keyword",
                                                        placeholder: "T\xecm kiếm ảnh",
                                                        className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["txt-search"])
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["sub-menu-right"]),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["nav-right"]),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "d-sm-none d-block",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["btn-open-search-m"]),
                                                onClick: handleOpenFormSearch,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 512 512",
                                                    width: "1em",
                                                    height: "1em",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M508.5 481.6l-129-129c-2.3-2.3-5.3-3.5-8.5-3.5h-10.3C395 312 416 262.5 416 208 416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c54.5 0 104-21 141.1-55.2V371c0 3.2 1.3 6.2 3.5 8.5l129 129c4.7 4.7 12.3 4.7 17 0l9.9-9.9c4.7-4.7 4.7-12.3 0-17zM208 384c-97.3 0-176-78.7-176-176S110.7 32 208 32s176 78.7 176 176-78.7 176-176 176z"
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: (_styles_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["btn-open-modal"]),
                                                onClick: handleModal,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text d-none d-sm-block",
                                                        children: "Gửi meme"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text2 d-block d-sm-none",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            viewBox: "0 0 384 512",
                                                            fill: "currentColor",
                                                            width: "1em",
                                                            height: "1em",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M368 224H224V80c0-8.84-7.16-16-16-16h-32c-8.84 0-16 7.16-16 16v144H16c-8.84 0-16 7.16-16 16v32c0 8.84 7.16 16 16 16h144v144c0 8.84 7.16 16 16 16h32c8.84 0 16-7.16 16-16V288h144c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16z"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            openModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modal_ModalUpload__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    }));
};

});

/***/ }),

/***/ 7686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_LeftSideBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(9816);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);
// EXTERNAL MODULE: ./styles/Term.module.scss
var Term_module = __webpack_require__(7257);
var Term_module_default = /*#__PURE__*/__webpack_require__.n(Term_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/actions/theme.js
var theme = __webpack_require__(9515);
;// CONCATENATED MODULE: external "lodash"
const external_lodash_namespaceObject = require("lodash");
;// CONCATENATED MODULE: ./components/Term/TermItem.jsx








function TermItem({ item  }) {
    const router = (0,router_.useRouter)();
    const media = (0,external_react_redux_.useSelector)((state)=>state.theme.media
    );
    const dispatch = (0,external_react_redux_.useDispatch)();
    const handlePermaLink = ()=>{
        if (media === "sm") {
            dispatch((0,theme/* toggleMenu */.js)(false));
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx((style_default()), {
                id: "2d9ac36e2073cb6d",
                dynamic: [
                    item.thumbnail
                ],
                children: `figure.__jsx-style-dynamic-selector{background-image:url(${item.thumbnail})}`
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: style_default().dynamic([
                    [
                        "2d9ac36e2073cb6d",
                        [
                            item.thumbnail
                        ]
                    ]
                ]) + " " + ((Term_module_default())["term-item"] + ` position-relative ` + (router.query.slug == item.slug ? (Term_module_default()).active : "") || ""),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `/tag/${item.slug}`,
                        /*#__PURE__*/ children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            title: item.title,
                            onClick: handlePermaLink,
                            className: style_default().dynamic([
                                [
                                    "2d9ac36e2073cb6d",
                                    [
                                        item.thumbnail
                                    ]
                                ]
                            ]) + " " + "full"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: style_default().dynamic([
                            [
                                "2d9ac36e2073cb6d",
                                [
                                    item.thumbnail
                                ]
                            ]
                        ]) + " " + ((Term_module_default())["term-content"] || ""),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: style_default().dynamic([
                                    [
                                        "2d9ac36e2073cb6d",
                                        [
                                            item.thumbnail
                                        ]
                                    ]
                                ]) + " " + ((Term_module_default())["term-image"] + ` mb-0` || 0)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: style_default().dynamic([
                                    [
                                        "2d9ac36e2073cb6d",
                                        [
                                            item.thumbnail
                                        ]
                                    ]
                                ]) + " " + ((Term_module_default())["term-title"] || ""),
                                children: item.title
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./components/layouts/LeftSideBar.jsx



function LeftSideBar({ classHtml , term  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `left-sidebar ${classHtml}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "left-sidebar-container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    children: "Tất cả danh mục"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: term && term.map((item)=>{
                        return(/*#__PURE__*/ jsx_runtime_.jsx(TermItem, {
                            item: item
                        }, `term_${item.id}`));
                    })
                })
            ]
        })
    }));
}
/* harmony default export */ const layouts_LeftSideBar = (/*#__PURE__*/external_react_default().memo(LeftSideBar));


/***/ }),

/***/ 2911:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MainLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_actions_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9515);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3155);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7064);
/* harmony import */ var _LeftSideBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7686);
/* harmony import */ var _RightSideBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6790);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_RightSideBar__WEBPACK_IMPORTED_MODULE_6__, _Header__WEBPACK_IMPORTED_MODULE_4__]);
([_RightSideBar__WEBPACK_IMPORTED_MODULE_6__, _Header__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);








function MainLayout({ children , footer , term  }) {
    const openMenu = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.theme.openMenu
    );
    const media = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.theme.media
    );
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleWidth = ()=>{
            if (window.innerWidth < 1250 && media !== "sm") {
                console.log("sm");
                dispatch((0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_7__/* .setMediaWidth */ .lm)("sm"));
                dispatch((0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_7__/* .toggleMenu */ .js)(false));
            }
            if (window.innerWidth >= 1250 && media !== "lg") {
                console.log("lg");
                dispatch((0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_7__/* .setMediaWidth */ .lm)("lg"));
            }
        };
        "load resize".split(" ").map((m)=>{
            window.addEventListener(m, handleWidth);
        });
        return ()=>{
            "load resize".split(" ").map((m)=>{
                window.removeEventListener(m, handleWidth);
            });
        };
    }, [
        media,
        dispatch
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "body",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "container",
                    children: [
                        openMenu && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LeftSideBar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            term: term,
                            classHtml: openMenu ? "open-menu" : ""
                        }),
                        openMenu && media === "sm" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            onClick: ()=>{
                                dispatch((0,_redux_actions_theme__WEBPACK_IMPORTED_MODULE_7__/* .toggleMenu */ .js)(false));
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            id: "page",
                            className: !openMenu && media === "lg" ? "type2" : "",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "clearfix",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "main-wrap",
                                        children: children
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RightSideBar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                ...footer
            })
        ]
    }));
};

});

/***/ }),

/***/ 6790:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RightSideBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_posts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1237);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7269);
/* harmony import */ var _Post_PostFeatured__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(924);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([reactstrap__WEBPACK_IMPORTED_MODULE_3__]);
reactstrap__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function RightSideBar() {
    const { 0: items , 1: setItems  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: loadMore , 1: setLoadMore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: end , 1: setEnd  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: nextPage , 1: setNextPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(2);
    const { 0: spinner , 1: setSpinner  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const list = document.getElementById(`in2-scroll`);
        const handleScroll = ()=>{
            if (list.scrollTop + list.clientHeight >= list.children[0].scrollHeight && !loadMore) {
                setLoadMore(!loadMore);
            }
        };
        list.addEventListener("scroll", handleScroll);
        return ()=>{
            list.removeEventListener("scroll", handleScroll);
        };
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoadMore(false);
        setEnd(false);
        setSpinner(false);
        setNextPage(2);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, [
        loadMore
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const getFirstData = async ()=>{
            const data = await _api_posts__WEBPACK_IMPORTED_MODULE_2__/* ["default"].featured */ .Z.featured({
                page: 1
            });
            setItems(data);
        };
        getFirstData();
    }, []);
    const getData = async ()=>{
        if (loadMore && !end) {
            setSpinner(true);
            const data = await _api_posts__WEBPACK_IMPORTED_MODULE_2__/* ["default"].featured */ .Z.featured({
                page: nextPage
            });
            const clone = [
                ...items
            ];
            setEnd(data.length ? false : true);
            setLoadMore(!loadMore);
            setNextPage((prevPage)=>{
                return prevPage + 1;
            });
            setItems(clone.concat(data));
            setSpinner(false);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "sidebar",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "sidebar-content",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    children: "B\xe0i viết nổi bật"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "in2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "in2-scroll",
                        id: "in2-scroll",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "infinite-list",
                            children: [
                                items.map((item)=>{
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Post_PostFeatured__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        item: item
                                    }, item.id));
                                }),
                                spinner && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Progress, {
                                    animated: true,
                                    color: "success",
                                    varlue: 100
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};

});

/***/ }),

/***/ 2581:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_layouts_MainLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2911);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7888);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_MainLayout__WEBPACK_IMPORTED_MODULE_4__]);
_components_layouts_MainLayout__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const TopProgressBar = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(null, {
    loadableGenerated: {
        modules: [
            "_app.jsx -> " + "../components/TopProgressBar"
        ]
    },
    ssr: false
});
function MyApp({ Component , pageProps , footer , meta , term  }) {
    const GA_MEASUREMENT_ID = "G-NW5E0L3V17";
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "dns-prefetch",
                        href: "https://memevui.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "dns-prefetch",
                        href: "https://cdn.memevui.com/"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "dns-prefetch",
                        href: "//facebook.com/"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "dns-prefetch",
                        href: "https://www.googletagmanager.com/"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/images/favicon-memevui.png",
                        type: "image/x-icon"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1.0, width=device-width"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "robots",
                        content: "index,follow"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify({
                                "@context": "https://schema.org",
                                "@type": "WebSite",
                                url: meta.url,
                                name: meta.site_name,
                                description: meta.site_description,
                                address: {
                                    "@type": "PostalAddress",
                                    addressLocality: "Ho Chi Minh",
                                    addressRegion: "VietNam",
                                    postalCode: "70000"
                                },
                                potentialAction: {
                                    "@type": "SearchAction",
                                    target: meta.search_url,
                                    "query-input": "required name=search_term_string"
                                }
                            })
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify({
                                "@context": "https://schema.org",
                                "@type": "WebPage",
                                name: meta.site_name,
                                description: meta.site_description
                            })
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        async: true,
                        src: `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        dangerouslySetInnerHTML: {
                            __html: `function gtag(){window.dataLayer.push(arguments)}window.dataLayer=window.dataLayer||[],gtag("js",new Date),gtag("config","${GA_MEASUREMENT_ID}");`
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TopProgressBar, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_MainLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                footer: footer,
                term: term,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    }));
}
MyApp.getInitialProps = async ()=>{
    const APP_URL = process.env.APP_URL;
    const res_meta = await fetch(`${APP_URL}/api/page/init`);
    const meta = await res_meta.json();
    const term_data = await fetch(`${APP_URL}/api/term/all`);
    const term = await term_data.json();
    const r_footer = await fetch(`${APP_URL}/api/layout/footer-content`);
    const footer = await r_footer.json();
    const appProps = {
        footer,
        meta,
        term
    };
    return appProps;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_redux_store__WEBPACK_IMPORTED_MODULE_5__/* .wrapper.withRedux */ .Y.withRedux(MyApp));

});

/***/ }),

/***/ 9515:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$J": () => (/* binding */ toggleModal),
/* harmony export */   "js": () => (/* binding */ toggleMenu),
/* harmony export */   "lm": () => (/* binding */ setMediaWidth)
/* harmony export */ });
const toggleModal = (value)=>{
    return {
        type: 'TOGGLE_MODAL',
        payload: value
    };
};
const toggleMenu = (value)=>{
    return {
        type: 'TOGGLE_MENU',
        payload: value
    };
};
const setMediaWidth = (value)=>{
    return {
        type: 'SET_MEDIA',
        payload: value
    };
};



/***/ }),

/***/ 7888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Y": () => (/* binding */ wrapper)
});

;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: ./redux/reducers/themeReducer.js
const initState = {
    openMenu: true,
    openModal: false,
    media: "lg"
};
const themeReducer = (state = initState, action)=>{
    switch(action.type){
        case "TOGGLE_MODAL":
            return {
                ...state,
                openModal: action.payload
            };
        case "TOGGLE_MENU":
            return {
                ...state,
                openMenu: action.payload
            };
        case "SET_MEDIA":
            return {
                ...state,
                media: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const reducers_themeReducer = (themeReducer);

;// CONCATENATED MODULE: ./redux/reducers/rootReducer.js


/* harmony default export */ const rootReducer = ((0,external_redux_namespaceObject.combineReducers)({
    theme: reducers_themeReducer
}));

;// CONCATENATED MODULE: ./redux/store.js



const makeStore = ()=>(0,external_redux_namespaceObject.createStore)(rootReducer)
;
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore);


/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9103:
/***/ ((module) => {

"use strict";
module.exports = require("query-string");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5623:
/***/ ((module) => {

"use strict";
module.exports = require("react-google-recaptcha");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

"use strict";
module.exports = require("styled-jsx/style");

/***/ }),

/***/ 4316:
/***/ ((module) => {

"use strict";
module.exports = require("vanilla-lazyload");

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 7269:
/***/ ((module) => {

"use strict";
module.exports = import("reactstrap");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,152,642,237,771], () => (__webpack_exec__(2581)));
module.exports = __webpack_exports__;

})();