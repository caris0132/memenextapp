"use strict";
(() => {
var exports = {};
exports.id = 83;
exports.ids = [83];
exports.modules = {

/***/ 9884:
/***/ ((module) => {

module.exports = require("http-proxy");

/***/ }),

/***/ 9619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var http_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9884);
/* harmony import */ var http_proxy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(http_proxy__WEBPACK_IMPORTED_MODULE_0__);

const proxy = http_proxy__WEBPACK_IMPORTED_MODULE_0___default().createProxyServer();
const config = {
    api: {
        bodyParser: false
    }
};
function handler(req, res1) {
    if (req.method !== "POST") {
        return res1.status(404).json({
            message: "method not supported"
        });
    }
    return new Promise((resolve, reject)=>{
        proxy.once('proxyRes', function(proxyRes, req, res) {
            var body = [];
            proxyRes.on('data', function(chunk) {
                body.push(chunk);
            });
            proxyRes.on('end', function() {
                body = Buffer.concat(body).toString();
                res.json(body);
                res.status(200).end();
            });
            resolve(true);
        });
        proxy.web(req, res1, {
            target: process.env.API_URL,
            changeOrigin: true,
            selfHandleResponse: true
        });
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9619));
module.exports = __webpack_exports__;

})();