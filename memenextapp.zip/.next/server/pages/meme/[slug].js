(() => {
var exports = {};
exports.id = 682;
exports.ids = [682];
exports.modules = {

/***/ 8249:
/***/ ((module) => {

// Exports
module.exports = {
	"photo-detail": "Detail_photo-detail__3iJur",
	"photo-detail-main-container": "Detail_photo-detail-main-container__Lti_M",
	"photo-detail-sidebar": "Detail_photo-detail-sidebar__21h6V",
	"photo-detail-title": "Detail_photo-detail-title__xV3zC",
	"icon-zoom-plus": "Detail_icon-zoom-plus__uCcDe",
	"gallery-item": "Detail_gallery-item__RFkGU",
	"btn-en": "Detail_btn-en__O4JsV",
	"hvr": "Detail_hvr__ZnXU_",
	"icon-en": "Detail_icon-en__s0BtB",
	"text-en": "Detail_text-en__kVW3W",
	"photo-detail-engagementBar": "Detail_photo-detail-engagementBar__VO6nQ",
	"photo-detail-content-wrapper": "Detail_photo-detail-content-wrapper__yTGjs",
	"engagementBar-sticky": "Detail_engagementBar-sticky__42kXH",
	"term-recommended": "Detail_term-recommended__BQ1IY",
	"photo-page-section-title-large-text": "Detail_photo-page-section-title-large-text__C98gS"
};


/***/ }),

/***/ 3319:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Thumbnail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Detail_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8249);
/* harmony import */ var _styles_Detail_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Detail_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7269);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([reactstrap__WEBPACK_IMPORTED_MODULE_2__]);
reactstrap__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* eslint-disable @next/next/no-img-element */ 



function Thumbnail({ thumbnail  }) {
    const { 0: openModal , 1: setOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleModal = (e)=>{
        e.preventDefault();
        setOpenModal(!openModal);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "gallery position-relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_styles_Detail_module_scss__WEBPACK_IMPORTED_MODULE_4___default()["icon-zoom-plus"]),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            src: "/images/btn-zoom-plus.svg",
                            alt: "Button zoom plus",
                            width: 24,
                            height: 24
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("figure", {
                        className: (_styles_Detail_module_scss__WEBPACK_IMPORTED_MODULE_4___default()["gallery-item"]) + ` position-relative`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "#",
                                className: "full",
                                onClick: handleModal,
                                children: " "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                alt: thumbnail.title,
                                src: thumbnail.thumbnail,
                                title: thumbnail.title,
                                width: thumbnail.width,
                                height: thumbnail.height,
                                className: "img-center img-responsive"
                            })
                        ]
                    })
                ]
            }),
            openModal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                isOpen: true,
                toggle: handleModal,
                centered: true,
                size: "lg",
                fade: false,
                className: "modal-light-box",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.ModalHeader, {
                        toggle: handleModal
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.ModalBody, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: thumbnail.thumbnail,
                            alt: "thumbnail.title",
                            width: thumbnail.width,
                            height: thumbnail.height,
                            title: thumbnail.title,
                            className: "img-responsive"
                        })
                    })
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 6282:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vanilla_lazyload__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4316);
/* harmony import */ var vanilla_lazyload__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vanilla_lazyload__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Detail_TheContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1771);
/* harmony import */ var _components_Detail_Thumbnail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3319);
/* harmony import */ var _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(561);
/* harmony import */ var _components_Post_PostHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1948);
/* harmony import */ var _config_lazyload__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6477);
/* harmony import */ var _components_Post_PostItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9115);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_10__, _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_7__, _components_Detail_Thumbnail__WEBPACK_IMPORTED_MODULE_6__, _components_Post_PostHeader__WEBPACK_IMPORTED_MODULE_8__]);
([_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_10__, _components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_7__, _components_Detail_Thumbnail__WEBPACK_IMPORTED_MODULE_6__, _components_Post_PostHeader__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











function Detail({ item , meta , term , apiUrl  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: items , 1: setItems  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const url = `${apiUrl}?cmd=bai-viet-khac`;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const getMorePost = async ()=>{
            const res = await fetch(url);
            const data = await res.json();
            setItems(data);
        };
        getMorePost();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        apiUrl
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (!document.lazyLoadInstance) {
            document.lazyLoadInstance = new (vanilla_lazyload__WEBPACK_IMPORTED_MODULE_4___default())(_config_lazyload__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
        }
        document.lazyLoadInstance.update();
    }, []);
    if (router.isFallback) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                fontSize: `2rem`,
                textAlign: `center`
            },
            children: "Loading..."
        }));
    }
    const thumbnail = {
        thumbnail: item.thumbnail,
        title: item.title,
        width: item.imageWidth,
        height: item.imageHeight
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: meta.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: meta.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: meta.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "article"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:type",
                        content: meta.mimeType
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:width",
                        content: meta.imageWidth
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:height",
                        content: meta.imageHeight
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:alt",
                        content: meta.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: meta.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "canonical",
                        href: meta.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: meta.share_image
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "amphtml",
                        href: meta.amp_link
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify({
                                "@context": "http://schema.org",
                                "@type": "NewsArticle",
                                name: meta.title,
                                description: meta.description,
                                url: meta.url,
                                image: meta.share_image,
                                mainEntityOfPage: {
                                    "@type": "WebPage",
                                    "@id": meta.url
                                },
                                headline: meta.title,
                                author: {
                                    "@type": "Person",
                                    name: "memevui.com",
                                    url: "https://memevui.com"
                                },
                                datePublished: meta.datePublished,
                                dateModified: meta.dateModified,
                                publisher: {
                                    "@type": "Organization",
                                    name: "Meme vui",
                                    logo: {
                                        "@type": "ImageObject",
                                        url: "/images/memevui.svg"
                                    }
                                }
                            })
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Post_PostHeader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        tag: "h1",
                        term: term[0],
                        header: {
                            post_title: item.title,
                            slug: item.slug,
                            origin_image: item.origin_image
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Detail_Thumbnail__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        thumbnail: thumbnail
                    }),
                    item.content && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Detail_TheContent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        content: item.content
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "post-more-divider",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            children: "C\xe1c b\xe0i đăng kh\xe1c từ MEMEVUI"
                        })
                    }),
                    items && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_InfiniteScroll__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        items: items,
                        setItems: setItems,
                        apiUrl: url,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Post_PostItem__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                    })
                ]
            })
        ]
    }));
}
async function getStaticPaths() {
    const API_URL = process.env.APP_URL;
    const res = await fetch(`${API_URL}/api/post/1000post`);
    // console.log(`--------------------------------body--------------------------------`,await res.text());
    const data = await res.json();
    return {
        paths: data.map((x)=>({
                params: {
                    slug: x.slug.toString() + `-` + x.id.toString()
                }
            })
        ),
        fallback: `blocking`
    };
}
async function getStaticProps(context) {
    const slug = context.params?.slug;
    const postId = parseInt(slug.substring(slug.lastIndexOf("-") + 1));
    if (!postId) return {
        notFound: true
    };
    const API_URL = process.env.APP_URL;
    const url = `${API_URL}/api/post/${postId}`;
    const res = await fetch(url);
    const data = await res.json();
    // console.log(res.text());
    if (data.notFound === true) return {
        notFound: true
    };
    return {
        props: {
            item: data.item,
            meta: data.meta,
            term: data.this_term,
            postId: postId,
            apiUrl: url
        },
        revalidate: 60
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Detail);

});

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9103:
/***/ ((module) => {

"use strict";
module.exports = require("query-string");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

"use strict";
module.exports = require("styled-jsx/style");

/***/ }),

/***/ 4316:
/***/ ((module) => {

"use strict";
module.exports = require("vanilla-lazyload");

/***/ }),

/***/ 7269:
/***/ ((module) => {

"use strict";
module.exports = import("reactstrap");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,642,793,771], () => (__webpack_exec__(6282)));
module.exports = __webpack_exports__;

})();