"use strict";
exports.id = 642;
exports.ids = [642];
exports.modules = {

/***/ 642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export LazyImage */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vanilla_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4316);
/* harmony import */ var vanilla_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vanilla_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_lazyload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6477);




// Only initialize it one time for the entire application
class LazyImage extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    // Update lazyLoad after first rendering of every image
    componentDidMount() {
        if (!document.lazyLoadInstance) {
            document.lazyLoadInstance = new (vanilla_lazyload__WEBPACK_IMPORTED_MODULE_2___default())(_config_lazyload__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
        }
        document.lazyLoadInstance.update();
    }
    // Update lazyLoad after rerendering of every image
    componentDidUpdate() {
        document.lazyLoadInstance.update();
    }
    // Just render the image with data-src
    render() {
        const { alt , src , srcset , sizes , width , height  } = this.props;
        return(// eslint-disable-next-line @next/next/no-img-element
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            alt: alt,
            className: "lazy",
            "data-src": src,
            "data-srcset": srcset,
            "data-sizes": sizes,
            width: width,
            height: height
        }));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LazyImage);


/***/ }),

/***/ 6477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    elements_selector: ".lazy"
});


/***/ })

};
;