"use strict";
exports.id = 237;
exports.ids = [237];
exports.modules = {

/***/ 1646:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9103);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);


const axiosClient = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://memevui.com" + `/api`,
    headers: {
        'content-type': 'application/json'
    },
    paramsSerializer: (params)=>query_string__WEBPACK_IMPORTED_MODULE_1___default().stringify(params)
});
// Handle token
axiosClient.interceptors.request.use(async (config)=>{
    // Do something before request is sent
    return config;
}, (error)=>{
    // Do something with request error
    return Promise.reject(error);
});
axiosClient.interceptors.response.use((response)=>{
    if (response && response.data) {
        return response.data;
    }
    return response;
}, (error)=>{
    throw error;
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosClient);


/***/ }),

/***/ 1237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1646);

const posts = {
    featured: (params)=>{
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get('/post/featured', {
            params
        });
    },
    all: (params)=>{
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get('/post', {
            params
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (posts);


/***/ })

};
;