export default {
    elements_selector: ".lazy"
};